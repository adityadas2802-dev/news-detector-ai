# TruthGuard AI

TruthGuard AI is a React/Vite frontend and FastAPI backend for looking up published fact checks. It does not produce an AI-generated truth score. When Google returns no matching review, the report says no match was found and does not claim that the story is true or false.

## Run on Windows

Terminal 1, from this folder:

```powershell
Copy-Item backend/.env.example backend/.env
python -m pip install -r backend/requirements.txt
python -m uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Terminal 2:

```powershell
Copy-Item .env.example .env.local
npm install
npm run dev
```

Open the Vite URL printed in the terminal (normally `http://localhost:5173`). `backend/.env` can stay empty to check connectivity; text/url analysis will clearly report that the provider key is missing. To run real fact-check lookups, enable the Google Fact Check Tools API in a Google Cloud project, create an API key, and place it in `backend/.env` as `GOOGLE_FACTCHECK_API_KEY=...`. Keep this key server-side; never put it in a `VITE_` variable or commit it. Restart the backend after adding the key.

The backend exposes `GET /health`, `POST /api/analyze`, `POST /api/analyze-url`, `GET /api/history`, and `GET /api/report/{id}`. Reports are saved to a local SQLite database at `backend/truthguard.sqlite3`. URL fetching is limited to public HTTP(S) hosts and blocks private/local network addresses.

Google Fact Check Tools searches its published ClaimReview records; it does not assess every claim in every article. Source ratings are shown as the publisher's ratings, with links and dates. No matching record is not evidence of truth. See [Google's API docs](https://developers.google.com/fact-check/tools/api/reference/rest/v1alpha1/claims/search).

## Frontend features

Routes: overview, analyzer, results, dashboard, history, evidence, about, contact, and settings. Input validation, loading and connection errors, theme and language preferences, local report history, chart demonstrations, and print-to-PDF are included. Dashboard figures are explicitly demo data. Contact form is demo-only. Bengali/Hindi translation covers core shared text; other explanatory copy remains English.

## Build

```sh
npm run build
```
