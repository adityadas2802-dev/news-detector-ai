from __future__ import annotations

import ipaddress
import json
import os
import socket
import sqlite3
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlsplit
from uuid import uuid4

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, HttpUrl

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "truthguard.sqlite3"
GOOGLE_API = "https://factchecktools.googleapis.com/v1alpha1/claims:search"


def _load_backend_env() -> None:
    env_file = ROOT / ".env"
    if not env_file.exists():
        return
    for raw_line in env_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"\''))


_load_backend_env()
app = FastAPI(title="TruthGuard AI API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)


def _connect() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def _init_db() -> None:
    with _connect() as db:
        db.execute("CREATE TABLE IF NOT EXISTS reports (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, input TEXT NOT NULL, mode TEXT NOT NULL, language TEXT NOT NULL, report_json TEXT NOT NULL)")


_init_db()


class TextRequest(BaseModel):
    text: str = Field(min_length=40, max_length=20000)
    language: str = Field(default="en", pattern="^(en|bn|hi)$")


class UrlRequest(BaseModel):
    url: HttpUrl
    language: str = Field(default="en", pattern="^(en|bn|hi)$")


class PageText(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.ignored = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "noscript", "svg", "nav", "footer", "header", "form"}:
            self.ignored += 1

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript", "svg", "nav", "footer", "header", "form"} and self.ignored:
            self.ignored -= 1

    def handle_data(self, data: str) -> None:
        if not self.ignored:
            value = " ".join(data.split())
            if value:
                self.parts.append(value)


def _assert_public_url(url: str) -> None:
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
        raise HTTPException(status_code=400, detail="Use a public HTTP or HTTPS article URL without embedded credentials.")
    if parsed.port not in (None, 80, 443):
        raise HTTPException(status_code=400, detail="Only standard public web ports are supported.")
    try:
        addresses = {entry[4][0] for entry in socket.getaddrinfo(parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)}
        if not addresses or any(not ipaddress.ip_address(address).is_global for address in addresses):
            raise HTTPException(status_code=400, detail="Private and local network URLs cannot be analyzed.")
    except socket.gaierror as exc:
        raise HTTPException(status_code=400, detail="The article host could not be resolved.") from exc


async def _read_article(url: str) -> str:
    current = url
    async with httpx.AsyncClient(timeout=12, follow_redirects=False, trust_env=False, headers={"User-Agent": "TruthGuardAI/1.0 (article text extraction)"}) as client:
        for _ in range(4):
            _assert_public_url(current)
            try:
                async with client.stream("GET", current) as response:
                    if response.is_redirect:
                        location = response.headers.get("location")
                        if not location:
                            raise HTTPException(status_code=400, detail="The article redirected without a destination.")
                        current = urljoin(current, location)
                        continue
                    if response.status_code >= 400:
                        raise HTTPException(status_code=422, detail=f"The article page returned HTTP {response.status_code}.")
                    if "text/html" not in response.headers.get("content-type", "").lower():
                        raise HTTPException(status_code=422, detail="The URL must point to an HTML article page.")
                    content = bytearray()
                    async for chunk in response.aiter_bytes():
                        content.extend(chunk)
                        if len(content) > 1_500_000:
                            raise HTTPException(status_code=413, detail="The article page is too large to process.")
                    parser = PageText()
                    parser.feed(bytes(content).decode(response.encoding or "utf-8", errors="replace"))
                    text = " ".join(parser.parts)
                    if len(text) < 40:
                        raise HTTPException(status_code=422, detail="Not enough readable article text was found. Paste the article text instead.")
                    return text[:20000]
            except HTTPException:
                raise
            except httpx.HTTPError as exc:
                raise HTTPException(status_code=502, detail="The article page could not be fetched. Paste the article text instead.") from exc
        raise HTTPException(status_code=400, detail="The article redirected too many times.")


def _assessment(rating: str) -> str:
    value = rating.casefold()
    if any(word in value for word in ("false", "incorrect", "pants on fire", "not true", "fake")):
        return "Contradicted"
    if any(word in value for word in ("misleading", "mixture", "half true", "partly true", "partially true", "mostly false")):
        return "Misleading" if "misleading" in value else "Partially Supported"
    if any(word in value for word in ("true", "correct", "accurate", "verified")) and not any(word in value for word in ("unverified", "not true", "not accurate")):
        return "Supported"
    return "Unverified"


def _save_report(report: dict[str, Any], source_text: str, mode: str, language: str) -> None:
    with _connect() as db:
        db.execute(
            "INSERT OR REPLACE INTO reports (id, created_at, input, mode, language, report_json) VALUES (?, ?, ?, ?, ?, ?)",
            (report["id"], report["createdAt"], source_text[:20000], mode, language, json.dumps(report, ensure_ascii=False)),
        )


async def _lookup(text: str, language: str, mode: str) -> dict[str, Any]:
    api_key = os.getenv("GOOGLE_FACTCHECK_API_KEY", "").strip()
    if not api_key:
        raise HTTPException(status_code=503, detail="Backend connected, but fact-check lookup is not configured. Add GOOGLE_FACTCHECK_API_KEY to backend/.env. No claim assessment was generated.")
    params: dict[str, str | int] = {"key": api_key, "query": text[:1000], "pageSize": 10}
    params["languageCode"] = {"en": "en-US", "bn": "bn-BD", "hi": "hi-IN"}[language]
    try:
        async with httpx.AsyncClient(timeout=20, trust_env=False) as client:
            response = await client.get(GOOGLE_API, params=params)
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail="The fact-check provider could not be reached. No claim assessment was generated.") from exc
    if response.status_code in (401, 403):
        raise HTTPException(status_code=502, detail="The fact-check provider rejected its API key. Check GOOGLE_FACTCHECK_API_KEY in backend/.env.")
    if response.status_code == 429:
        raise HTTPException(status_code=503, detail="The fact-check provider rate limit was reached. Try again later.")
    if response.status_code >= 400:
        raise HTTPException(status_code=502, detail=f"The fact-check provider returned HTTP {response.status_code}.")

    payload = response.json()
    claims: list[dict[str, Any]] = []
    for item in payload.get("claims", []):
        evidence = []
        for review in item.get("claimReview", []):
            publisher = review.get("publisher", {}) or {}
            rating = review.get("textualRating") or "Unrated"
            evidence.append({
                "title": review.get("title") or "Fact-check review",
                "publisher": publisher.get("name") or "Publisher unavailable",
                "published_at": review.get("reviewDate"),
                "url": review.get("url"),
                "summary": f"Publisher rating: {rating}. A publisher's review is evidence to inspect, not a guarantee of truth.",
                "relation": rating,
            })
        ratings = [review.get("textualRating") or "" for review in item.get("claimReview", [])]
        mapped = [_assessment(rating) for rating in ratings]
        verdict = mapped[0] if mapped and all(value == mapped[0] for value in mapped) else "Unverified"
        claims.append({"text": item.get("text") or "", "assessment": verdict, "explanation": "Assessment reflects the rating(s) in published ClaimReview entries; inspect each linked source and its context.", "evidence": evidence})

    statuses = [claim["assessment"] for claim in claims]
    overall = statuses[0] if statuses and all(value == statuses[0] for value in statuses) else "Unverified"
    explanation = (
        f"Found {len(claims)} published fact-check claim record(s). These are publisher reviews, not an independent guarantee that the article or claim is true."
        if claims else "No matching published fact-check record was returned. This does not establish whether the claim is true or false."
    )
    report = {"id": str(uuid4()), "createdAt": datetime.now(timezone.utc).isoformat(), "assessment": overall, "explanation": explanation, "claims": claims, "provider": "Google Fact Check Tools API"}
    _save_report(report, text, mode, language)
    return report


@app.get("/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "service": "truthguard-api", "fact_check_provider_configured": bool(os.getenv("GOOGLE_FACTCHECK_API_KEY", "").strip())}


@app.get("/")
def root() -> dict[str, Any]:
    return {
        "service": "TruthGuard AI API",
        "status": "ok",
        "health": "/health",
        "docs": "/docs",
        "fact_check_provider_configured": bool(os.getenv("GOOGLE_FACTCHECK_API_KEY", "").strip()),
    }


@app.post("/api/analyze")
async def analyze_text(request: TextRequest) -> dict[str, Any]:
    return {"report": await _lookup(request.text.strip(), request.language, "text")}


@app.post("/api/analyze-url")
async def analyze_url(request: UrlRequest) -> dict[str, Any]:
    if not os.getenv("GOOGLE_FACTCHECK_API_KEY", "").strip():
        raise HTTPException(status_code=503, detail="Backend connected, but fact-check lookup is not configured. Add GOOGLE_FACTCHECK_API_KEY to backend/.env. No claim assessment was generated.")
    article_text = await _read_article(str(request.url))
    return {"report": await _lookup(article_text, request.language, "url")}


@app.get("/api/history")
def history() -> dict[str, list[dict[str, Any]]]:
    with _connect() as db:
        rows = db.execute("SELECT id, created_at, input, mode, language, report_json FROM reports ORDER BY created_at DESC LIMIT 100").fetchall()
    return {"history": [{"id": row["id"], "createdAt": row["created_at"], "input": row["input"], "mode": row["mode"], "language": row["language"], "report": json.loads(row["report_json"])} for row in rows]}


@app.get("/api/report/{report_id}")
def get_report(report_id: str) -> dict[str, Any]:
    with _connect() as db:
        row = db.execute("SELECT report_json FROM reports WHERE id = ?", (report_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Report not found.")
    return {"report": json.loads(row["report_json"])}
