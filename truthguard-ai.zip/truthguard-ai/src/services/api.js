import axios from 'axios';
const api = axios.create({ baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000', timeout: 30000, headers: { 'Content-Type': 'application/json' } });
export const analyzeText = (text, language) => api.post('/api/analyze', { text, language });
export const analyzeUrl = (url, language) => api.post('/api/analyze-url', { url, language });
export const getHistory = () => api.get('/api/history');
export const getReport = (id) => api.get(`/api/report/${encodeURIComponent(id)}`);
export const healthCheck = () => api.get('/health');
export const errorMessage = (error) => error?.response?.data?.detail || (error?.code === 'ECONNABORTED' ? 'The analysis timed out. Your input is still here—please try again.' : 'TruthGuard could not reach the analysis service. Check that the API is running, then try again. Your input is preserved.');
